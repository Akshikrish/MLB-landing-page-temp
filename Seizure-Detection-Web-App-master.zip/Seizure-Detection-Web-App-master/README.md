# SeizureDetectionWebApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version
10.0.5.

## Preperation

If you have just cloned the project, run `npm install` to install the necessary library to run the
project.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically
reload if you change any of the source files.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.
Use the `--prod` flag for a production build.

## Deploy

Run `firebase deploy` on the project folder. You need to setup your own firebase project first and
install firebase-tools. Tutorials on firebase-tools can be found online.
